#######################################################
# Name           : Yayan Multi Brute Facebook (YMBF)  #
# File           : run.py                             #
# Author         : Moch Yayan Juan Alvredo XD.        #
# Github         : https://github.com/Yayan-XD        #
# Facebook       : https://www.facebook.com/KM39453   #
# Website        : https://www.yayanxd.my.id          #
# Python version : 0.3                                #
#######################################################

############# DON'T REMOVE THIS FUNCTIONS #############

import os
from src import cok as yy

if __name__ == "__main__":
    os.system("git pull");os.system("rm -rf results/OK/...");os.system("rm -rf results/CP/...")
    yy.cek_server()
