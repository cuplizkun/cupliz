
#### CARA INSTALL SCRIPT:
 download aplikasi termux android di [sini!](https://f-droid.org/repo/com.termux_117.apk), lalu buka aplikasinya ketikan perintah dibawah ini.
 ```
 $ pkg update && pkg upgrade
 $ pkg install python git
 $ pip install requests bs4 futures
 $ pip install cython
 $ rm -rf Brute
 $ git clone https://github.com/Yayan-XD/Brute
 ```
 oke sekarang script sudah terinstall
#### CARA MENJALANKAN SCRIPT:
 sekarang karena script sudah diinstall tinggal kita jalankan, ketikan perintah dibawah ini:
 ```
  $ cd Brute
  $ git pull
 ```
#### GUNAKAN INI UNTUK MENGGANTI BAHASA
```
Indonesia : python run.py id
English   : python run.py en
```
### TAMPILAN AWAL:
![template_s](https://github.com/Yayan-XD/Brute/blob/master/__pycache__/IMG_20210703_070319.jpg)
 ketik *trial* jika anda ingin mendapatkan key trial 1 hari., atau bisa juga ketik *admin* untuk mendapatkan informasi selanjutnya.

### LOGIN COOKIE:

![template_s](https://github.com/Yayan-XD/Brute/blob/master/__pycache__/IMG_20210703_074349.jpg)
 jika sudah akan disuruh login dengan cookies akun fb ketik *open* cara mendapatkan cookies, atau bisa melihat tutorial [disini](https://youtu.be/DF7bUCn0GFY).
#### RESULTS CRACK FB:
![template_s](https://github.com/Yayan-XD/Brute/blob/master/__pycache__/pict.jpg)
* Notice me: *jika mendapatkan akun cp simpan 1/3, hari lalu loginkan.*

#### RESULTS CRACK IG:
![template_s](https://github.com/Yayan-XD/Brute/blob/master/__pycache__/Screenshot_20211127_123029.jpg)
* Notice me: Hasil crack followers banyak atau sedikit nya tergantung target yang di dapatkan.

##### info:
 untuk versi sekarang hanya support di perangkat yang *aarch64* untuk mengecek
 ketik perintah ini : ```uname -m``` jika muncul *aarch64* selamat anda bisa menggunakan script ini,
 oh iya script ini juga cuma bisa dijalanin dipython veri 3.9 untuk mengecek versi python
 ketik perintah ini : ```python --version```

##### catatan:
 gunakanlah dengan bijak, atas apapun yang terjadi admin tidak bertanggung jawab.

###### Thanks for [Yayan-XD](https://github.com/Yayan-XD) and [Rizky Dev](https://github.com/hekelpro)

